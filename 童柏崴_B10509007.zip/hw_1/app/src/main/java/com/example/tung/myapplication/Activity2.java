package com.example.tung.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity {
    private TextView textview1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        textview1=(TextView) this.findViewById(R.id.textview1);
        Bundle bundle = this.getIntent().getExtras();
        String msg = bundle.getString("key");
        textview1.setText("B10509007:"+msg);

    }
}
